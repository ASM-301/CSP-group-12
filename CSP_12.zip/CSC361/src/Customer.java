

	public class Customer {



		    int demand;
		    int timeWindowStart;
		    int timeWindowEnd;

		    public Customer(int demand, int timeWindowStart, int timeWindowEnd) {
		        this.demand = demand;
		        this.timeWindowStart = timeWindowStart;
		        this.timeWindowEnd = timeWindowEnd;
		    }
		}
	
	
	
	

		
		
		
	


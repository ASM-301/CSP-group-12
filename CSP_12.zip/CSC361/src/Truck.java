
class Truck {
    int capacity;

    public Truck(int capacity) {
        this.capacity = capacity;
    }
}

